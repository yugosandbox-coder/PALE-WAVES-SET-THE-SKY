# PALE WAVES SET THE SKY

ブラウザで遊べるバレーボールゲームです。

## GitHub Pages での公開

1. このフォルダの中身（index.html / game.js / tut フォルダ / README.md）をリポジトリのいちばん上に置きます。
2. リポジトリの Settings → Pages を開きます。
3. Source を「Deploy from a branch」、Branch を main と / (root) にして Save します。
4. 数分たつと https://<ユーザー名>.github.io/<リポジトリ名>/ で遊べます。

- index.html と game.js は必ず同じ場所に置いてください。
- tut フォルダ（チュートリアルのカード画像 01〜27.webp）も index.html と同じ場所に、フォルダごと置いてください。無いとチュートリアルのカードが表示されません（ゲーム自体は動きます）。
- オンライン対戦は専用のルームサーバー（Cloudflare Workers）につながるので、別途サーバーを用意する必要はありません。
